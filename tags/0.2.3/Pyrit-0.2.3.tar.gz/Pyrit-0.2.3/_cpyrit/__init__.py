__all__ = ['_cpyrit_cpu', '_cpyrit_util']
VERSION = '0.2.3 (svn r133)'
