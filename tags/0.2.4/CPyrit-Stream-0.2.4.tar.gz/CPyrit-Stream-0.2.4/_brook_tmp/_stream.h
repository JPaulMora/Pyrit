#ifndef __STREAM_AUTO_GENERATED_H_
#define __STREAM_AUTO_GENERATED_H_

/**************************************************************************** 
                                                                              
Copyright (c) 2003, Stanford University                                       
All rights reserved.                                                          
                                                                              
Copyright (c) 2008, Advanced Micro Devices, Inc.                              
All rights reserved.                                                          
                                                                              
                                                                              
The BRCC portion of BrookGPU is derived from the cTool project                
(http://ctool.sourceforge.net) and distributed under the GNU Public License.  
                                                                              
Additionally, see LICENSE.ctool for information on redistributing the         
contents of this directory.                                                   
                                                                              
****************************************************************************/ 

#include "brook/Stream.h" 
#include "brook/KernelInterface.h" 

//! Kernel declarations
class __sha1_rounds
{
    public:
        void operator()(const ::brook::Stream< uint2 >& ipad_A, const ::brook::Stream< uint2 >& ipad_B, const ::brook::Stream< uint2 >& ipad_C, const ::brook::Stream< uint2 >& ipad_D, const ::brook::Stream< uint2 >& ipad_E, const ::brook::Stream< uint2 >& opad_A, const ::brook::Stream< uint2 >& opad_B, const ::brook::Stream< uint2 >& opad_C, const ::brook::Stream< uint2 >& opad_D, const ::brook::Stream< uint2 >& opad_E, const ::brook::Stream< uint2 >& pmk_in0, const ::brook::Stream< uint2 >& pmk_in1, const ::brook::Stream< uint2 >& pmk_in2, const ::brook::Stream< uint2 >& pmk_in3, const ::brook::Stream< uint2 >& pmk_in4, const ::brook::Stream<  uint2 >& pmk_out0, const ::brook::Stream<  uint2 >& pmk_out1, const ::brook::Stream<  uint2 >& pmk_out2, const ::brook::Stream<  uint2 >& pmk_out3, const ::brook::Stream<  uint2 >& pmk_out4, const uint2  W5_init);
        EXTENDCLASS();
};
extern __THREAD__ __sha1_rounds sha1_rounds;

#endif // __STREAM_AUTO_GENERATED_H_

